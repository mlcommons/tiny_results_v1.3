#!/usr/bin/env python3
# Copyright (c) 2023 SpacemiT. All rights reserved.
from .graphwise import statistical_analyse
